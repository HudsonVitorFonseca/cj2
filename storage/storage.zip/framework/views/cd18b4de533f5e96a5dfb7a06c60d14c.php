
<?php $__env->startSection('admin'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<style type="text/css">
  .form-check-label{
    text-transform: capitalize;
  }
</style>

<div class="page-content">

       
        <div class="row profile-body">
          <!-- left wrapper start -->
          
          <!-- left wrapper end -->
          <!-- middle wrapper start -->
          <div class="col-md-12 col-xl-12 middle-wrapper">
            <div class="row">
             <div class="card">
              <div class="card-body">

			<h6 class="card-title">Edit Roles in Permission   </h6>

	 <form id="myForm" method="POST" action="<?php echo e(route('admin.roles.update',$role->id)); ?>" class="forms-sample">
				<?php echo csrf_field(); ?>
 

				<div class="form-group mb-3">
 <label for="exampleInputEmail1" class="form-label">Roles Name   </label>
	   <h3><?php echo e($role->name); ?></h3>
           
				</div>


    <div class="form-check mb-2">
                  <input type="checkbox" class="form-check-input" id="checkDefaultmain">
                  <label class="form-check-label" for="checkDefaultmain">
                   Permission All 
                  </label>
                </div>
 
 <hr>

 <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row">
        <div class="col-3">

 <?php
  $permissions = App\Models\User::getpermissionByGroupName($group->group_name)
  ?>

          <div class="form-check mb-2">
      <input type="checkbox" class="form-check-input" id="checkDefault" <?php echo e(App\Models\User::roleHasPermissions($role,$permissions) ? 'checked' : ''); ?> >
                  <label class="form-check-label" for="checkDefault">
                   <?php echo e($group->group_name); ?>

                  </label>
                </div>

          
        </div>


         <div class="col-9">

 

      <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="form-check mb-2">
     
      <input type="checkbox" class="form-check-input" name="permission[]" id="checkDefault<?php echo e($permission->id); ?>" value="<?php echo e($permission->id); ?>" <?php echo e($role->hasPermissionTo($permission->name) ? 'checked' : ''); ?> >
     
    <label class="form-check-label" for="checkDefault<?php echo e($permission->id); ?>">
                   <?php echo e($permission->name); ?>

                  </label>
                </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
        </div>
        
      </div> <!-- // End Row  -->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 




			 
				 
	 <button type="submit" class="btn btn-primary me-2">Save Changes </button>
			 
			</form>

              </div>
            </div>




            </div>
          </div>
          <!-- middle wrapper end -->
          <!-- right wrapper start -->
         
          <!-- right wrapper end -->
        </div>

			</div>

    <script type="text/javascript">
        
        $('#checkDefaultmain').click(function(){

          if ($(this).is(':checked')) {
            $('input[ type= checkbox]').prop('checked',true);
          }else{
             $('input[ type= checkbox]').prop('checked',false);
          }

        });
    </script>  
 
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\Project6\realestate\resources\views/backend/pages/rolesetup/edit_roles_permission.blade.php ENDPATH**/ ?>