
<?php $__env->startSection('admin'); ?>


<div class="page-content">

				<nav class="page-breadcrumb">
					<ol class="breadcrumb">
	  <a href="<?php echo e(route('add.type')); ?>" class="btn btn-inverse-info"> Add Property Type  </a>
					</ol>
				</nav>

				<div class="row">
					<div class="col-md-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h6 class="card-title">Property Type All </h6>
               
                <div class="table-responsive">
                  <table id="dataTableExample" class="table">
                    <thead>
                      <tr>
                        <th>Sl </th>
                        <th>Type Name </th>
                        <th>Type Icon </th>
                        <th>Action </th> 
                      </tr>
                    </thead>
                    <tbody>
                   <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><?php echo e($item->type_name); ?></td>
                        <td><?php echo e($item->type_icon); ?></td>
         

                        <td>

        <?php if(Auth::user()->can('edit.type')): ?>                   
       <a href="<?php echo e(route('edit.type',$item->id)); ?>" class="btn btn-inverse-warning"> Edit </a>
       <?php endif; ?>
        <?php if(Auth::user()->can('delete.type')): ?>
       <a href="<?php echo e(route('delete.type',$item->id)); ?>" class="btn btn-inverse-danger" id="delete"> Delete  </a>
        <?php endif; ?>
                        </td> 
                      </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
					</div>
				</div>

			</div>









<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\Project6\realestate\resources\views/backend/type/all_type.blade.php ENDPATH**/ ?>