
<?php $__env->startSection('admin'); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

 <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

<div class="page-content">

				<nav class="page-breadcrumb">
					<ol class="breadcrumb">
	  <a href="<?php echo e(route('add.admin')); ?>" class="btn btn-inverse-info"> Add Admin    </a>
					</ol>
				</nav>

				<div class="row">
					<div class="col-md-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h6 class="card-title">Admin All </h6>
               
                <div class="table-responsive">
                  <table id="dataTableExample" class="table">
                    <thead>
                      <tr>
                        <th>Sl </th>
                        <th>Image </th> 
                        <th>Name </th> 
                        <th>Email </th> 
                        <th>Phone </th> 
                        <th>Role </th>  
                        <th>Action </th> 
                      </tr>
                    </thead>
                    <tbody>
                   <?php $__currentLoopData = $alladmin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><img src="<?php echo e((!empty($item->photo)) ? url('upload/admin_images/'.$item->photo) : url('upload/no_image.jpg')); ?>" style="width:70px; height:40px;"> </td> 
                        <td><?php echo e($item->name); ?></td> 
                       <td><?php echo e($item->email); ?></td> 
                       <td><?php echo e($item->phone); ?></td> 
                       <td>
                      <?php $__currentLoopData = $item->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span class="badge badge-pill bg-danger"><?php echo e($role->name); ?></span>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </td>   
                        <td> 
       <a href="<?php echo e(route('edit.admin',$item->id)); ?>" class="btn btn-inverse-warning" title="Edit"> <i data-feather="edit"></i> </a>

       <a href="<?php echo e(route('delete.admin',$item->id)); ?>" class="btn btn-inverse-danger" id="delete" title="Delete"> <i data-feather="trash-2"></i>  </a>
                        </td> 
                      </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
					</div>
				</div>

			</div>
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\localhost\htdocs\Project6\realestate\resources\views/backend/pages/admin/all_admin.blade.php ENDPATH**/ ?>