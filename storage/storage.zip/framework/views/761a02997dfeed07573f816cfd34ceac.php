 <section class="video-section centred" style="background-image: url(<?php echo e(asset('frontend/assets/images/background/video-1.jpg')); ?>);">
            <div class="auto-container">
                <div class="video-inner">
                    <div class="video-btn">
                        <a href="https://www.youtube.com/watch?v=nfP5N9Yc72A&amp;t=28s" class="lightbox-image" data-caption=""><i class="icon-17"></i></a>
                    </div>
                </div>
            </div>
        </section><?php /**PATH C:\localhost\htdocs\Project6\realestate\resources\views/frontend/home/video.blade.php ENDPATH**/ ?>