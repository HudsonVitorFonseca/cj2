
<?php $__env->startSection('main'); ?>

<?php $__env->startSection('title'); ?>
  Easy Real Estate Complete Project  
<?php $__env->stopSection(); ?>

        <!-- banner-section -->
         <?php echo $__env->make('frontend.home.banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- banner-section end -->
 

 
<!-- category-section -->
  <?php echo $__env->make('frontend.home.category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- category-section end -->


        <!-- feature-section -->
       <?php echo $__env->make('frontend.home.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- feature-section end -->


        <!-- video-section -->
         <?php echo $__env->make('frontend.home.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- video-section end -->


        <!-- deals-section -->
       <?php echo $__env->make('frontend.home.deals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- deals-section end -->


        <!-- testimonial-section end -->
      <?php echo $__env->make('frontend.home.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- testimonial-section end -->


        <!-- chooseus-section -->
         <?php echo $__env->make('frontend.home.chooseus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- chooseus-section end -->


        <!-- place-section -->
        <?php echo $__env->make('frontend.home.place', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- place-section end -->


        <!-- team-section -->
         <?php echo $__env->make('frontend.home.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- team-section end -->


        <!-- cta-section -->
      <?php echo $__env->make('frontend.home.cta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- cta-section end -->


        <!-- news-section -->
       <?php echo $__env->make('frontend.home.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- news-section end -->


        <!-- download-section -->
       <?php echo $__env->make('frontend.home.download', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- download-section end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.frontend_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gretho\Desktop\Cursos_e_Estudos\Udemy\php_Real_Estate\completo\realestate\resources\views/frontend/index.blade.php ENDPATH**/ ?>