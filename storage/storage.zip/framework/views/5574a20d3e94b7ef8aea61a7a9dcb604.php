  <footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
        <p class="text-muted mb-1 mb-md-0">Copyright © 2022 <a href="https://easylearningbd.com" target="_blank">EasyLearning</a>.</p>
        <p class="text-muted">EasyLearning With <i class="mb-1 text-primary ms-1 icon-sm" data-feather="heart"></i></p>
      </footer><?php /**PATH C:\Users\Gretho\Desktop\Cursos_e_Estudos\Udemy\php_Real_Estate\completo\realestate\resources\views/agent/body/footer.blade.php ENDPATH**/ ?>